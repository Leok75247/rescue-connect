export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#0066FF",
        accent: "#FF3B30",
        success: "#4CAF50",
      },
    },
  },
  plugins: [],
};
