// src/components/Footer.tsx
import React from 'react';
import { FaFacebook, FaTwitter, FaInstagram, FaLinkedin } from 'react-icons/fa';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-gray-200 py-10 mt-10">
      <div className="max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* About */}
        <div>
          <h2 className="text-xl font-bold mb-4">Healthcare Portal</h2>
          <p className="text-gray-400">
            Your trusted online healthcare platform. Manage appointments, access diet plans, track deliveries, and more.
          </p>
        </div>

        {/* Quick Links */}
        <div>
          <h2 className="text-xl font-bold mb-4">Quick Links</h2>
          <ul className="space-y-2">
            <li>
              <a href="/" className="hover:text-white transition">Home</a>
            </li>
            <li>
              <a href="/auth" className="hover:text-white transition">Login / Register</a>
            </li>
            <li>
              <a href="/settings" className="hover:text-white transition">Settings</a>
            </li>
            <li>
              <a href="/donors" className="hover:text-white transition">Donor List</a>
            </li>
          </ul>
        </div>

        {/* Contact & Social */}
        <div>
          <h2 className="text-xl font-bold mb-4">Contact Us</h2>
          <p className="text-gray-400">Email: support@healthcare.com</p>
          <p className="text-gray-400">Phone: +91 12345 67890</p>
          <div className="flex space-x-4 mt-4">
            <a href="#" className="hover:text-white transition">
              <FaFacebook size={20} />
            </a>
            <a href="#" className="hover:text-white transition">
              <FaTwitter size={20} />
            </a>
            <a href="#" className="hover:text-white transition">
              <FaInstagram size={20} />
            </a>
            <a href="#" className="hover:text-white transition">
              <FaLinkedin size={20} />
            </a>
          </div>
        </div>
      </div>

      <div className="text-center text-gray-500 mt-8 text-sm">
        &copy; {new Date().getFullYear()} Healthcare Portal. All rights reserved.
      </div>
    </footer>
  );
};

export default Footer;
