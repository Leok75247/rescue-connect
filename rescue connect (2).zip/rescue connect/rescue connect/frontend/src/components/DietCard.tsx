// src/components/DietCard.tsx
import React from 'react';
import { DietPlan } from '../types/type';

interface DietCardProps {
  diet: DietPlan;
  onSelect?: (diet: DietPlan) => void; // optional click handler
}

const DietCard: React.FC<DietCardProps> = ({ diet, onSelect }) => {
  return (
    <div
      className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition cursor-pointer"
      onClick={() => onSelect && onSelect(diet)}
    >
      <h2 className="text-xl font-bold mb-2">{diet.name}</h2>
      <p className="text-gray-600 mb-2">{diet.description}</p>
      <ul className="text-gray-700 text-sm list-disc list-inside mb-2">
        {diet.items.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>
      <p className="text-gray-500 text-sm">Calories: {diet.calories} kcal</p>
    </div>
  );
};

export default DietCard;
