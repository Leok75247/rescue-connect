import React from 'react';
import Map from '../components/Map';
import { Delivery } from '../types/type';

const sampleDeliveries: Delivery[] = [
  {
    id: 1,
    patientName: 'John Doe',
    address: '123 Street, City',
    status: 'pending',
    scheduledTime: '2025-11-07T10:00:00Z',
  },
  {
    id: 2,
    patientName: 'Jane Smith',
    address: '456 Avenue, City',
    status: 'in-progress',
    scheduledTime: '2025-11-07T12:00:00Z',
  },
];

const MapPage: React.FC = () => {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Delivery Map</h1>
      <Map deliveries={sampleDeliveries} />
    </div>
  );
};

export default MapPage;
