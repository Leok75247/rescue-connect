// src/components/Toast.tsx
import React, { useEffect } from 'react';

export type ToastType = 'success' | 'error' | 'info';

export interface ToastProps {
  id: string;
  type: ToastType;
  message: string;
  duration?: number; // in ms
  onClose: (id: string) => void;
}

const Toast: React.FC<ToastProps> = ({ id, type, message, duration = 3000, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => onClose(id), duration);
    return () => clearTimeout(timer);
  }, [id, duration, onClose]);

  const bgColor = {
    success: 'bg-green-500',
    error: 'bg-red-500',
    info: 'bg-blue-500',
  };

  return (
    <div
      className={`flex items-center justify-between ${bgColor[type]} text-white px-4 py-2 rounded shadow-md mb-2`}
    >
      <span>{message}</span>
      <button onClick={() => onClose(id)} className="ml-4 font-bold hover:opacity-80">
        ×
      </button>
    </div>
  );
};

export default Toast;
