import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto flex justify-between items-center p-4">
        <Link to="/" className="text-2xl font-bold text-primary">
          RescueConnect
        </Link>
        <div className="flex gap-4">
          <Link to="/ambulance" className="hover:text-primary">Ambulance</Link>
          <Link to="/blood" className="hover:text-primary">Blood</Link>
          <Link to="/nutrition" className="hover:text-primary">Nutrition</Link>
        </div>
      </div>
    </nav>
  );
}
