// src/components/RequestCard.tsx
import React from 'react';
import { Request } from '../types/type';

interface RequestCardProps {
  request: Request;
  onAction?: (id: number, action: 'approved' | 'rejected') => void;
}

const RequestCard: React.FC<RequestCardProps> = ({ request, onAction }) => {
  const statusColor = {
    pending: 'text-yellow-500',
    approved: 'text-green-500',
    rejected: 'text-red-500',
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition flex flex-col justify-between">
      <div>
        <h2 className="text-xl font-bold mb-1">{request.patientName}</h2>
        <p className="text-gray-600 mb-1">Request: {request.requestType}</p>
        <p className="text-gray-500 mb-2">{request.details}</p>
        <p className={`font-medium ${statusColor[request.status]}`}>
          Status: {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
        </p>
        <p className="text-gray-400 text-sm mt-1">
          Requested at: {new Date(request.requestedAt).toLocaleString()}
        </p>
      </div>

      {request.status === 'pending' && onAction && (
        <div className="flex space-x-2 mt-4">
          <button
            onClick={() => onAction(request.id, 'approved')}
            className="flex-1 bg-green-500 text-white py-2 rounded hover:bg-green-600 transition"
          >
            Approve
          </button>
          <button
            onClick={() => onAction(request.id, 'rejected')}
            className="flex-1 bg-red-500 text-white py-2 rounded hover:bg-red-600 transition"
          >
            Reject
          </button>
        </div>
      )}
    </div>
  );
};

export default RequestCard;
