// src/pages/DonorList.tsx
import React, { useState, useEffect } from 'react';
import { Donor } from '../types/type';
import { getDonors } from '../utils/mockApi'; // placeholder for API

const DonorList: React.FC = () => {
  const [donors, setDonors] = useState<Donor[]>([]);
  const [search, setSearch] = useState<string>('');
  const [filterBloodGroup, setFilterBloodGroup] = useState<string>('');

  useEffect(() => {
    // Fetch donors from backend API (replace with real API)
    const fetchDonors = async () => {
      const data = await getDonors(); // mock API
      setDonors(data);
    };
    fetchDonors();
  }, []);

  const filteredDonors = donors.filter((donor) => {
    return (
      donor.name.toLowerCase().includes(search.toLowerCase()) &&
      (filterBloodGroup ? donor.bloodGroup === filterBloodGroup : true)
    );
  });

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6 text-center">Donor List</h1>

      {/* Search & Filter */}
      <div className="flex flex-col md:flex-row gap-4 mb-6 justify-center">
        <input
          type="text"
          placeholder="Search by name..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="border rounded px-3 py-2 w-full md:w-1/3 focus:outline-none focus:ring-2 focus:ring-blue-400"
        />

        <select
          value={filterBloodGroup}
          onChange={(e) => setFilterBloodGroup(e.target.value)}
          className="border rounded px-3 py-2 w-full md:w-1/4 focus:outline-none focus:ring-2 focus:ring-blue-400"
        >
          <option value="">All Blood Groups</option>
          <option value="A+">A+</option>
          <option value="A-">A-</option>
          <option value="B+">B+</option>
          <option value="B-">B-</option>
          <option value="O+">O+</option>
          <option value="O-">O-</option>
          <option value="AB+">AB+</option>
          <option value="AB-">AB-</option>
        </select>
      </div>

      {/* Donor Cards */}
      <div className="grid gap-4 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
        {filteredDonors.length === 0 ? (
          <p className="text-center col-span-full text-gray-600">
            No donors found.
          </p>
        ) : (
          filteredDonors.map((donor) => (
            <div
              key={donor.id}
              className="bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition"
            >
              <h2 className="text-xl font-semibold mb-1">{donor.name}</h2>
              <p className="text-gray-600 mb-1">Blood Group: {donor.bloodGroup}</p>
              <p className="text-gray-600 mb-1">City: {donor.city}</p>
              <p className="text-gray-500 text-sm">Contact: {donor.contact}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default DonorList;
