// src/components/LocationButton.tsx
import React, { useState } from 'react';

interface LocationButtonProps {
  onLocationFetch?: (coords: { lat: number; lng: number }) => void;
  label?: string;
  className?: string;
}

const LocationButton: React.FC<LocationButtonProps> = ({
  onLocationFetch,
  label = 'Get My Location',
  className = '',
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleClick = () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser.');
      return;
    }

    setLoading(true);
    setError(null);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLoading(false);
        const coords = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };
        if (onLocationFetch) {
          onLocationFetch(coords);
        } else {
          alert(`Latitude: ${coords.lat}, Longitude: ${coords.lng}`);
        }
      },
      (err) => {
        setLoading(false);
        setError(err.message || 'Unable to retrieve location.');
      }
    );
  };

  return (
    <div className="flex flex-col items-center">
      <button
        onClick={handleClick}
        className={`bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition ${className}`}
        disabled={loading}
      >
        {loading ? 'Fetching...' : label}
      </button>
      {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
    </div>
  );
};

export default LocationButton;
