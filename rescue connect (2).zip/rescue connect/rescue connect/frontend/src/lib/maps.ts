// src/utils/maps.ts
import { Loader } from '@googlemaps/js-api-loader';

const GOOGLE_MAPS_API_KEY = 'YOUR_GOOGLE_MAPS_API_KEY'; // replace with your key

// Load Google Maps API
export const loadGoogleMaps = (): Promise<typeof google.maps> => {
  const loader = new Loader({
    apiKey: GOOGLE_MAPS_API_KEY,
    version: 'weekly',
  });

  return loader.load().then(() => google.maps);
};

// Initialize a map
export const initMap = (
  mapContainer: HTMLElement | null,
  center: { lat: number; lng: number } = { lat: 12.9716, lng: 77.5946 }, // default Bangalore
  zoom: number = 12
): google.maps.Map | null => {
  if (!mapContainer) return null;

  const map = new google.maps.Map(mapContainer, {
    center,
    zoom,
    mapTypeControl: false,
    streetViewControl: false,
    fullscreenControl: true,
  });

  return map;
};

// Add a marker
export const addMarker = (
  map: google.maps.Map,
  position: { lat: number; lng: number },
  title?: string
): google.maps.Marker => {
  const marker = new google.maps.Marker({
    position,
    map,
    title,
  });
  return marker;
};

// Fit map to bounds for multiple markers
export const fitBounds = (
  map: google.maps.Map,
  positions: { lat: number; lng: number }[]
) => {
  if (!positions.length) return;
  const bounds = new google.maps.LatLngBounds();
  positions.forEach((pos) => bounds.extend(pos));
  map.fitBounds(bounds);
};
