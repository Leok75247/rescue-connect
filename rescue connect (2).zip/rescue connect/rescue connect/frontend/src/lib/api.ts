// src/utils/api.ts
import axios, { AxiosInstance } from 'axios';
import { AuthForm, UserSettings, Delivery, ApiResponse } from '../types/type';

// Create an Axios instance
const api: AxiosInstance = axios.create({
  baseURL: process.env.REACT_APP_API_BASE_URL || 'http://localhost:5000/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Optional: Add a request interceptor for JWT token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token'); // assuming you store JWT in localStorage
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// -------------------------
// Auth APIs
// -------------------------
export const login = async (data: AuthForm): Promise<ApiResponse<{ token: string }>> => {
  const response = await api.post('/auth/login', data);
  return response.data;
};

export const register = async (data: AuthForm): Promise<ApiResponse<{ token: string }>> => {
  const response = await api.post('/auth/register', data);
  return response.data;
};

// -------------------------
// Settings APIs
// -------------------------
export const getUserSettings = async (): Promise<ApiResponse<UserSettings>> => {
  const response = await api.get('/settings');
  return response.data;
};

export const updateUserSettings = async (data: UserSettings): Promise<ApiResponse> => {
  const response = await api.put('/settings', data);
  return response.data;
};

// -------------------------
// Driver / Delivery APIs
// -------------------------
export const getDriverDeliveries = async (): Promise<ApiResponse<Delivery[]>> => {
  const response = await api.get('/driver/deliveries');
  return response.data;
};

export const updateDeliveryStatus = async (
  id: number,
  status: Delivery['status']
): Promise<ApiResponse> => {
  const response = await api.put(`/driver/deliveries/${id}`, { status });
  return response.data;
};

// -------------------------
// Export the Axios instance for custom requests if needed
// -------------------------
export default api;
