// src/types/type.ts

// -------------------------
// User / Authentication Types
// -------------------------
export interface User {
  id: number;
  name: string;
  email: string;
  phone?: string;
  role: 'admin' | 'driver' | 'patient';
  token?: string; // for JWT authentication
}

export interface AuthForm {
  name?: string; // optional for login
  email: string;
  password: string;
}

// -------------------------
// Settings Types
// -------------------------
export interface UserSettings {
  fullName: string;
  email: string;
  phone: string;
  notifications: boolean;
}

// -------------------------
// Driver / Delivery Types
// -------------------------
export type DeliveryStatus = 'pending' | 'in-progress' | 'completed';

export interface Delivery {
  id: number;
  patientName: string;
  address: string;
  status: DeliveryStatus;
  scheduledTime: string;
}

// -------------------------
// API Response Types
// -------------------------
export interface ApiResponse<T = any> {
  success: boolean;
  message: string;
  data?: T;
}

// -------------------------
// Optional: For forms and validation
// -------------------------
export interface ValidationErrors<T> {
  [key: string]: string;
}
