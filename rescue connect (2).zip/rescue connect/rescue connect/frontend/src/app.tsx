import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import AmbulanceRequest from "./pages/AmbulanceRequest";
import DonorSearch from "./pages/DonorSearch";
import NutritionPlan from "./pages/NutritionPlan";

export default function App() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/ambulance" element={<AmbulanceRequest />} />
          <Route path="/blood" element={<DonorSearch />} />
          <Route path="/nutrition" element={<NutritionPlan />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}
