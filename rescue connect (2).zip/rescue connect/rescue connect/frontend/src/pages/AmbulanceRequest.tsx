import axios from "axios";
import { useState } from "react";

export default function AmbulanceRequest() {
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(false);

  const handleRequest = async () => {
    setLoading(true);
    try {
      const pos = await new Promise<GeolocationPosition>((resolve, reject) =>
        navigator.geolocation.getCurrentPosition(resolve, reject)
      );

      const { latitude, longitude } = pos.coords;
      const res = await axios.post("http://localhost:8080/api/ambulance/request", {
        latitude,
        longitude,
      });
      setStatus(res.data.message || "Request sent successfully!");
    } catch (err) {
      setStatus("Failed to send request. Please enable GPS.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8 text-center">
      <h2 className="text-2xl font-semibold mb-6">Request an Ambulance</h2>
      <button
        onClick={handleRequest}
        disabled={loading}
        className="bg-primary text-white px-6 py-3 rounded-lg hover:bg-blue-700"
      >
        {loading ? "Requesting..." : "Send Request"}
      </button>
      {status && <p className="mt-4 text-gray-700">{status}</p>}
    </div>
  );
}
