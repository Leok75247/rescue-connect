import { Link } from "react-router-dom";
import { FaAmbulance, FaHeartbeat, FaAppleAlt } from "react-icons/fa";

export default function Home() {
  return (
    <section className="text-center py-16 bg-gradient-to-b from-blue-50 to-white">
      <h1 className="text-4xl font-bold text-primary mb-4">
        Welcome to RescueConnect
      </h1>
      <p className="text-gray-600 mb-10">
        Your trusted healthcare partner for emergency response, blood donation, and nutrition.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
        <Link to="/ambulance" className="bg-white p-6 rounded-2xl shadow hover:shadow-lg">
          <FaAmbulance className="text-5xl text-primary mx-auto mb-3" />
          <h2 className="font-semibold text-lg">Request Ambulance</h2>
        </Link>
        <Link to="/blood" className="bg-white p-6 rounded-2xl shadow hover:shadow-lg">
          <FaHeartbeat className="text-5xl text-red-500 mx-auto mb-3" />
          <h2 className="font-semibold text-lg">Find Blood Donors</h2>
        </Link>
        <Link to="/nutrition" className="bg-white p-6 rounded-2xl shadow hover:shadow-lg">
          <FaAppleAlt className="text-5xl text-green-500 mx-auto mb-3" />
          <h2 className="font-semibold text-lg">Nutrition Plan</h2>
        </Link>
      </div>
    </section>
  );
}
