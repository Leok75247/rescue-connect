// src/pages/DriverDashboard.tsx
import React, { useEffect, useState } from 'react';
import axios from 'axios';

interface Delivery {
  id: number;
  patientName: string;
  address: string;
  status: 'pending' | 'in-progress' | 'completed';
  scheduledTime: string;
}

const DriverDashboard: React.FC = () => {
  const [deliveries, setDeliveries] = useState<Delivery[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    fetchDeliveries();
  }, []);

  const fetchDeliveries = async () => {
    try {
      setLoading(true);
      // Replace with your backend API
      const response = await axios.get<Delivery[]>('/api/driver/deliveries');
      setDeliveries(response.data);
    } catch (err) {
      setError('Failed to fetch deliveries');
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async (id: number, status: Delivery['status']) => {
    try {
      // Replace with your backend API
      await axios.put(`/api/driver/deliveries/${id}`, { status });
      setDeliveries((prev) =>
        prev.map((d) => (d.id === id ? { ...d, status } : d))
      );
    } catch (err) {
      setError('Failed to update status');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <h1 className="text-3xl font-bold mb-6 text-center">Driver Dashboard</h1>

      {loading ? (
        <p className="text-center text-gray-600">Loading deliveries...</p>
      ) : error ? (
        <p className="text-center text-red-500">{error}</p>
      ) : deliveries.length === 0 ? (
        <p className="text-center text-gray-600">No deliveries assigned.</p>
      ) : (
        <div className="grid gap-6 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
          {deliveries.map((delivery) => (
            <div
              key={delivery.id}
              className="bg-white p-4 rounded-lg shadow-md flex flex-col justify-between"
            >
              <div>
                <h2 className="text-xl font-semibold mb-1">
                  {delivery.patientName}
                </h2>
                <p className="text-gray-600 mb-1">{delivery.address}</p>
                <p className="text-gray-500 text-sm mb-2">
                  Scheduled: {new Date(delivery.scheduledTime).toLocaleString()}
                </p>
                <p
                  className={`font-medium mb-2 ${
                    delivery.status === 'pending'
                      ? 'text-yellow-500'
                      : delivery.status === 'in-progress'
                      ? 'text-blue-500'
                      : 'text-green-500'
                  }`}
                >
                  Status: {delivery.status.replace('-', ' ')}
                </p>
              </div>
              <div className="flex space-x-2 mt-2">
                {delivery.status !== 'completed' && (
                  <>
                    {delivery.status === 'pending' && (
                      <button
                        onClick={() =>
                          updateStatus(delivery.id, 'in-progress')
                        }
                        className="flex-1 bg-blue-500 text-white py-2 rounded hover:bg-blue-600 transition"
                      >
                        Start
                      </button>
                    )}
                    <button
                      onClick={() =>
                        updateStatus(delivery.id, 'completed')
                      }
                      className="flex-1 bg-green-500 text-white py-2 rounded hover:bg-green-600 transition"
                    >
                      Complete
                    </button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default DriverDashboard;
