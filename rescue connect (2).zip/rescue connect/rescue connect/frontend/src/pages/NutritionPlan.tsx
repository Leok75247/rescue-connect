import axios from "axios";
import { useState } from "react";

export default function NutritionPlan() {
  const [report, setReport] = useState("");
  const [plan, setPlan] = useState<any | null>(null);

  const getPlan = async () => {
    try {
      const res = await axios.post("http://localhost:8080/api/nutrition/generate", { report });
      setPlan(res.data);
    } catch {
      alert("Error generating plan.");
    }
  };

  return (
    <div className="p-8 text-center">
      <h2 className="text-2xl font-semibold mb-6">Get Personalized Nutrition Plan</h2>
      <textarea
        value={report}
        onChange={(e) => setReport(e.target.value)}
        placeholder="Describe your condition, allergies, etc."
        className="border rounded w-full md:w-1/2 p-3 h-32 mb-4"
      />
      <br />
      <button onClick={getPlan} className="bg-primary text-white px-6 py-2 rounded">
        Generate Plan
      </button>

      {plan && (
        <div className="mt-6 bg-white rounded-xl shadow p-6 mx-auto max-w-lg text-left">
          <h3 className="text-xl font-bold mb-2">Your Diet Plan</h3>
          <p>{plan.diet}</p>
          <h4 className="mt-4 font-semibold">Medication:</h4>
          <p>{plan.medication}</p>
        </div>
      )}
    </div>
  );
}
