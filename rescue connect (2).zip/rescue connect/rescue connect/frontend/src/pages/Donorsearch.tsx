import axios from "axios";
import { useState } from "react";

export default function DonorSearch() {
  const [bloodGroup, setBloodGroup] = useState("");
  const [donors, setDonors] = useState<any[]>([]);
  const [status, setStatus] = useState("");

  const searchDonors = async () => {
    setStatus("Searching...");
    try {
      const res = await axios.get(`http://localhost:8080/api/blood/search?group=${bloodGroup}`);
      setDonors(res.data || []);
      setStatus("");
    } catch {
      setStatus("Error fetching donors.");
    }
  };

  return (
    <div className="p-8 text-center">
      <h2 className="text-2xl font-semibold mb-6">Find Nearby Donors</h2>
      <input
        type="text"
        placeholder="Enter Blood Group (A+, O-, etc.)"
        value={bloodGroup}
        onChange={(e) => setBloodGroup(e.target.value)}
        className="border rounded p-2 mr-2"
      />
      <button onClick={searchDonors} className="bg-primary text-white px-4 py-2 rounded">
        Search
      </button>

      <p className="mt-4">{status}</p>
      <ul className="mt-6 space-y-3">
        {donors.map((d, i) => (
          <li key={i} className="border rounded-lg p-3 flex justify-between items-center bg-white shadow-sm">
            <span>{d.name} ({d.bloodGroup})</span>
            <button className="bg-green-500 text-white px-3 py-1 rounded">
              Contact
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
