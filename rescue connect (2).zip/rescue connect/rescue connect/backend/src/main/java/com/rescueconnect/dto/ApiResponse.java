package com.rescueconnect.dto;

public class ApiResponse {
    
}
