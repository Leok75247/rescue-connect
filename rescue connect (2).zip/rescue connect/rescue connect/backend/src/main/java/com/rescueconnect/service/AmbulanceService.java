package com.rescueconnect.service;

public class AmbulanceService {
    
}
