package com.rescueconnect.model;

public class User {
    
}
