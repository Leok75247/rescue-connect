package com.example.healthcareapp.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        // Enables a simple in-memory broker
        config.enableSimpleBroker("/topic"); // messages sent to /topic/... go to subscribers
        config.setApplicationDestinationPrefixes("/app"); // messages sent from client with /app/... go to controller
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        // Client will use this endpoint to connect
        registry.addEndpoint("/ws")
                .setAllowedOriginPatterns("*") // allow cross-origin requests
                .withSockJS(); // fallback for browsers that don’t support WebSocket
    }
}
