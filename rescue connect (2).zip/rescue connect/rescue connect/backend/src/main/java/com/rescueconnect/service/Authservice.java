package com.rescueconnect.service;

public class Authservice {
    
}
