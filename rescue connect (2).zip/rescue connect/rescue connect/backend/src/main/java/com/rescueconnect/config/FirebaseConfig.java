package com.example.healthcareapp;

import android.content.Context;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class FirebaseConfig {

    private static FirebaseAuth mAuth;
    private static FirebaseFirestore db;

    /**
     * Initialize Firebase manually (if not using google-services.json)
     */
    public static void initFirebase(Context context) {
        try {
            FirebaseOptions options = new FirebaseOptions.Builder()
                    .setApiKey("YOUR_API_KEY")
                    .setApplicationId("YOUR_APPLICATION_ID") // e.g., 1:1234567890:android:abcdef
                    .setDatabaseUrl("https://your-project-id.firebaseio.com")
                    .setProjectId("your-project-id")
                    .setStorageBucket("your-project-id.appspot.com")
                    .build();

            // Initialize Firebase App if not already initialized
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context, options);
            }

            // Initialize Firebase services
            mAuth = FirebaseAuth.getInstance();
            db = FirebaseFirestore.getInstance();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static FirebaseAuth getAuth() {
        return mAuth;
    }

    public static FirebaseFirestore getFirestore() {
        return db;
    }
}
