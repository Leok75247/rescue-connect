package com.example.healthcareapp;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

public class TwilioConfig {

    // Replace these with your Twilio account credentials
    private static final String ACCOUNT_SID = "YOUR_TWILIO_ACCOUNT_SID";
    private static final String AUTH_TOKEN = "YOUR_TWILIO_AUTH_TOKEN";
    private static final String FROM_PHONE = "+1234567890"; // Twilio verified number

    /**
     * Initialize Twilio SDK
     */
    public static void initTwilio() {
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
    }

    /**
     * Send SMS
     *
     * @param to      Recipient phone number (with country code)
     * @param message SMS content
     * @return Message SID
     */
    public static String sendSMS(String to, String message) {
        initTwilio(); // Ensure Twilio is initialized

        Message msg = Message.creator(
                new PhoneNumber(to),
                new PhoneNumber(FROM_PHONE),
                message
        ).create();

        return msg.getSid();
    }

    /**
     * Example usage
     */
    public static void main(String[] args) {
        String sid = sendSMS("+919876543210", "Hello! This is a test message from Healthcare Portal.");
        System.out.println("Message SID: " + sid);
    }
}

