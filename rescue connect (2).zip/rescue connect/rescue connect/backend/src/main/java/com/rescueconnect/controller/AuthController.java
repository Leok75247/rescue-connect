package com.rescueconnect.controller;

public class AuthController {
    
}
