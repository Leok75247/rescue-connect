package com.rescueconnect.model;

public class Location {
    
}
