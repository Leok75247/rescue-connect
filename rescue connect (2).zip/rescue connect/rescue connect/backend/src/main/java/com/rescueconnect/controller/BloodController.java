package com.example.healthcareapp.controller;

import com.example.healthcareapp.model.Blood;
import com.example.healthcareapp.repository.BloodRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/blood")
public class BloodController {

    @Autowired
    private BloodRepository bloodRepository;

    // Get all blood entries
    @GetMapping
    public List<Blood> getAllBlood() {
        return bloodRepository.findAll();
    }

    // Get blood entry by ID
    @GetMapping("/{id}")
    public ResponseEntity<Blood> getBloodById(@PathVariable Long id) {
        Optional<Blood> blood = bloodRepository.findById(id);
        return blood.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Add new blood entry
    @PostMapping
    public Blood addBlood(@RequestBody Blood blood) {
        return bloodRepository.save(blood);
    }

    // Update blood entry
    @PutMapping("/{id}")
    public ResponseEntity<Blood> updateBlood(@PathVariable Long id, @RequestBody Blood bloodDetails) {
        Optional<Blood> bloodOpt = bloodRepository.findById(id);
        if (bloodOpt.isPresent()) {
            Blood blood = bloodOpt.get();
            blood.setDonorName(bloodDetails.getDonorName());
            blood.setBloodGroup(bloodDetails.getBloodGroup());
            blood.setUnits(bloodDetails.getUnits());
            return ResponseEntity.ok(bloodRepository.save(blood));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Delete blood entry
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBlood(@PathVariable Long id) {
        if (bloodRepository.existsById(id)) {
            bloodRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}

