package com.example.healthcareapp.controller;

import com.example.healthcareapp.model.Nutrition;
import com.example.healthcareapp.repository.NutritionRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/nutrition")
public class NutritionController {

    @Autowired
    private NutritionRepository nutritionRepository;

    // Get all nutrition/diet plans
    @GetMapping
    public List<Nutrition> getAllNutrition() {
        return nutritionRepository.findAll();
    }

    // Get nutrition plan by ID
    @GetMapping("/{id}")
    public ResponseEntity<Nutrition> getNutritionById(@PathVariable Long id) {
        Optional<Nutrition> nutrition = nutritionRepository.findById(id);
        return nutrition.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Add new nutrition plan
    @PostMapping
    public Nutrition addNutrition(@RequestBody Nutrition nutrition) {
        return nutritionRepository.save(nutrition);
    }

    // Update nutrition plan
    @PutMapping("/{id}")
    public ResponseEntity<Nutrition> updateNutrition(@PathVariable Long id, @RequestBody Nutrition nutritionDetails) {
        Optional<Nutrition> nutritionOpt = nutritionRepository.findById(id);
        if (nutritionOpt.isPresent()) {
            Nutrition nutrition = nutritionOpt.get();
            nutrition.setTitle(nutritionDetails.getTitle());
            nutrition.setDescription(nutritionDetails.getDescription());
            nutrition.setCalories(nutritionDetails.getCalories());
            nutrition.setItems(nutritionDetails.getItems());
            return ResponseEntity.ok(nutritionRepository.save(nutrition));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Delete nutrition plan
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteNutrition(@PathVariable Long id) {
        if (nutritionRepository.existsById(id)) {
            nutritionRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}

