package com.rescueconnect.service;

public class Bloodservice {
    
}
