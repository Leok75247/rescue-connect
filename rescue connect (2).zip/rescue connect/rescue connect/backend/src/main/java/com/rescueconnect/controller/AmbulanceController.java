package com.example.healthcareapp.controller;

import com.example.healthcareapp.model.Ambulance;
import com.example.healthcareapp.repository.AmbulanceRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/ambulances")
public class AmbulanceController {

    @Autowired
    private AmbulanceRepository ambulanceRepository;

    // Get all ambulances
    @GetMapping
    public List<Ambulance> getAllAmbulances() {
        return ambulanceRepository.findAll();
    }

    // Get ambulance by ID
    @GetMapping("/{id}")
    public ResponseEntity<Ambulance> getAmbulanceById(@PathVariable Long id) {
        Optional<Ambulance> ambulance = ambulanceRepository.findById(id);
        if (ambulance.isPresent()) {
            return ResponseEntity.ok(ambulance.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Add new ambulance
    @PostMapping
    public Ambulance addAmbulance(@RequestBody Ambulance ambulance) {
        ambulance.setStatus("available"); // default status
        return ambulanceRepository.save(ambulance);
    }

    // Update ambulance status
    @PutMapping("/{id}/status")
    public ResponseEntity<Ambulance> updateStatus(@PathVariable Long id, @RequestParam String status) {
        Optional<Ambulance> ambulanceOpt = ambulanceRepository.findById(id);
        if (ambulanceOpt.isPresent()) {
            Ambulance ambulance = ambulanceOpt.get();
            ambulance.setStatus(status);
            return ResponseEntity.ok(ambulanceRepository.save(ambulance));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Delete ambulance
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAmbulance(@PathVariable Long id) {
        if (ambulanceRepository.existsById(id)) {
            ambulanceRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
